from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    pkg_share = get_package_share_directory('battlebot_sim')
    world_file = os.path.join(pkg_share, 'worlds', 'arena.world')
    urdf_file = os.path.join(pkg_share, 'urdf', 'battlebot.urdf')

    return LaunchDescription([
        ExecuteProcess(
            cmd=[
                'gazebo', '--verbose', world_file,
                '-s', 'libgazebo_ros_factory.so'
            ],
            additional_env={
                'GAZEBO_PLUGIN_PATH': '/opt/ros/foxy/lib',
                'LD_LIBRARY_PATH': '/opt/ros/foxy/lib:/opt/ros/foxy/lib/x86_64-linux-gnu',
            },
            output='screen'
        ),

        # ✅ robot_state_publisher
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': open(urdf_file).read()}]
        ),

        # ✅ spawn_entity (딜레이로 Gazebo 서비스 기다림)
        TimerAction(
            period=5.0,
            actions=[
                Node(
                    package='gazebo_ros',
                    executable='spawn_entity.py',
                    arguments=[
                        '-entity', 'battlebot',
                        '-file', urdf_file,
                        '-x', '0', '-y', '4', '-z', '0.3'
                    ],
                    output='screen'
                )
            ]
        ),

        # ✅ 장애물 컨트롤러 실행 (더 늦게 실행)
        TimerAction(
            period=10.0,
            actions=[
                Node(
                    package='battlebot_sim',
                    executable='moving_obstacle_controller',
                    name='moving_obstacle_controller',
                    output='screen'
                )
            ]
        ),

    ])

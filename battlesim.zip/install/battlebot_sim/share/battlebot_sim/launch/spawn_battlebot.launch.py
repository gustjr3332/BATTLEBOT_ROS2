from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    pkg_share = get_package_share_directory('battlebot_sim')
    world_file = os.path.join(pkg_share, 'worlds', 'arena.world')
    urdf_file = os.path.join(pkg_share, 'urdf', 'battlebot.urdf')

    return LaunchDescription([
        # Ignition Gazebo 실행
        ExecuteProcess(
            cmd=['ign', 'gazebo', '-v', '4', '-r', world_file],
            output='screen'
        ),

        # robot_state_publisher
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': open(urdf_file).read()}]
        ),

        # 로봇 스폰 (딜레이로 서비스 기다림)
        TimerAction(
            period=5.0,
            actions=[
                Node(
                    package='ros_ign_gazebo',
                    executable='create',
                    arguments=[
                        '-topic', '/robot_description',
                        '-name', 'battlebot',
                        '-x', '0', '-y', '4', '-z', '0.3'
                    ],
                    output='screen'
                )
            ]
        ),

        # ROS-Ignition 브릿지 (cmd_vel 토픽 연결)
        Node(
            package='ros_ign_bridge',
            executable='parameter_bridge',
            arguments=['/battlebot/cmd_vel@geometry_msgs/msg/Twist@ignition.msgs.Twist'],
            output='screen'
        ),

        # 장애물 컨트롤러 실행
        TimerAction(
            period=10.0,
            actions=[
                Node(
                    package='battlebot_sim',
                    executable='moving_obstacle_controller',
                    name='moving_obstacle_controller',
                    output='screen'
                )
            ]
        ),

        # 톱날 컨트롤러 실행
        TimerAction(
            period=10.0,
            actions=[
                Node(
                    package='battlebot_sim',
                    executable='saw_blade_controller',
                    name='saw_blade_controller',
                    output='screen'
                )
            ]
        ),

        # 키보드 조종 노드
        TimerAction(
            period=10.0,
            actions=[
                Node(
                    package='teleop_twist_keyboard',
                    executable='teleop_twist_keyboard',
                    name='teleop_twist_keyboard',
                    output='screen',
                    remappings=[('cmd_vel', '/battlebot/cmd_vel')]
                )
            ]
        ),
    ])

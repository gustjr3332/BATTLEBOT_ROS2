from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    pkg_share = get_package_share_directory('battlebot_sim')
    world_file = os.path.join(pkg_share, 'worlds', 'arena.world')
    urdf_file = os.path.join(pkg_share, 'urdf', 'battlebot.urdf')

    return LaunchDescription([
        # Ignition Gazebo 실행
        ExecuteProcess(
            cmd=['ign', 'gazebo', '-v', '4', '-r', world_file],
            output='screen'
        ),

        # robot_state_publisher
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': open(urdf_file).read()}]
        ),

        # 로봇 스폰 (더 긴 딜레이로 서비스 대기)
        TimerAction(
            period=7.0,  # 5.0에서 7.0으로 증가
            actions=[
                Node(
                    package='ros_ign_gazebo',
                    executable='create',
                    arguments=[
                        '-topic', '/robot_description',
                        '-name', 'battlebot',
                        '-x', '0', '-y', '4', '-z', '0.3'
                    ],
                    output='screen'
                )
            ]
        ),

        # ROS-Ignition 브릿지 (다중 토픽 연결)
        Node(
            package='ros_ign_bridge',
            executable='parameter_bridge',
            arguments=[
                '/battlebot/cmd_vel@geometry_msgs/msg/Twist@ignition.msgs.Twist',
                '/battlebot/odom@nav_msgs/msg/Odometry@ignition.msgs.Odometry',
                '/battlebot/saw_state@std_msgs/msg/Float64@ignition.msgs.Double',
                '/battlebot/contact@sensor_msgs/msg/Contacts@ignition.msgs.Contacts'
            ],
            output='screen'
        ),

        # 장애물 컨트롤러 실행
        TimerAction(
            period=8.0,  # 12.0에서 8.0으로 감소
            actions=[
                Node(
                    package='battlebot_sim',
                    executable='moving_obstacle_controller',
                    name='moving_obstacle_controller',
                    output='screen'
                )
            ]
        ),

        # 톱날 컨트롤러 실행
        TimerAction(
            period=8.0,  # 12.0에서 8.0으로 감소
            actions=[
                Node(
                    package='battlebot_sim',
                    executable='saw_blade_controller',
                    name='saw_blade_controller',
                    output='screen'
                )
            ]
        ),

        # 키보드 조종 노드
        TimerAction(
            period=8.0,  # 12.0에서 8.0으로 감소
            actions=[
                Node(
                    package='teleop_twist_keyboard',
                    executable='teleop_twist_keyboard',
                    name='teleop_twist_keyboard',
                    output='screen',
                    remappings=[('cmd_vel', '/battlebot/cmd_vel')]
                )
            ]
        ),
    ])

from setuptools import setup

package_name = 'battlebot_sim'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/battlebot_sim.launch.py']),
        ('share/' + package_name + '/urdf', ['urdf/battlebot.urdf']),
        ('share/' + package_name + '/worlds', ['worlds/arena.world']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='honggeun',
    maintainer_email='your@email.com',
    description='Battlebot simulator package',
    license='MIT',
    extras_require={
        'testing': ['pytest'],
    },
    entry_points={
        'console_scripts': [
            'moving_obstacle_controller = battlebot_sim.moving_obstacle_controller:main',
            'saw_blade_controller = battlebot_sim.saw_blade_controller:main'
        ],
    },
)

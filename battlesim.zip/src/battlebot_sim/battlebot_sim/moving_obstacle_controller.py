import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class MovingObstacleController(Node):
    def __init__(self):
        super().__init__('moving_obstacle_controller')

        self.publisher_ = self.create_publisher(Twist, '/moving_obstacle/cmd_vel', 10)
        self.direction = 1.0
        self.time_elapsed = 0.0
        self.speed = 0.5  # m/s
        self.max_time = 8.0  # 왕복 시간 (max_distance/speed ≈ 6s, 여유 시간 추가)
        self.timer_period = 0.1
        self.timer = self.create_timer(self.timer_period, self.timer_callback)

    def timer_callback(self):
        msg = Twist()
        msg.linear.x = self.direction * self.speed
        self.publisher_.publish(msg)

        self.time_elapsed += self.timer_period
        if self.time_elapsed >= self.max_time:
            self.direction *= -1.0
            self.time_elapsed = 0.0  # 시간 초기화
            self.get_logger().info(f'방향 전환: {self.direction}')

def main(args=None):
    rclpy.init(args=args)
    node = MovingObstacleController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

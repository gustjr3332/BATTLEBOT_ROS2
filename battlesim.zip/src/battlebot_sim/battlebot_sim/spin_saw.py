import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64

class SpinSaw(Node):
    def __init__(self):
        super().__init__('spin_saw')
        self.publisher = self.create_publisher(Float64, '/saw_blade_1/cmd_vel', 10)  # saw_blade_1만 제어
        self.timer = self.create_timer(0.1, self.timer_callback)
        self.effort = 5.0  # rad/s로 해석

    def timer_callback(self):
        msg = Float64()
        msg.data = self.effort
        self.publisher.publish(msg)
        self.get_logger().info(f'Publishing speed: {self.effort} rad/s')

def main(args=None):
    rclpy.init(args=args)
    node = SpinSaw()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

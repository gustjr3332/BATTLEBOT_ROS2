import os
from glob import glob
from setuptools import setup

package_name = 'battlebot_sim'  # 패키지 이름 설정

setup(
    name=package_name,
    version='0.0.0',  # 버전
    packages=[package_name],  # 포함할 파이썬 패키지
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),  # 리소스 인덱스
        ('share/' + package_name, ['package.xml']),  # 패키지 메타데이터
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),  # launch 파일
        (os.path.join('share', package_name, 'urdf'), glob('urdf/*.urdf')),  # URDF 파일
        (os.path.join('share', package_name, 'worlds'), glob('worlds/*.world')),  # 월드 파일
        (os.path.join('share', package_name, 'models'), glob('models/**/*.*', recursive=True)),  # 모델 파일
        ('share/' + package_name + '/config', ['config/params.yaml']),  # 설정 파일
    ],
    install_requires=['setuptools'],  # 설치 요구 사항
    zip_safe=True,
    maintainer='honggeun',  # 유지 관리자
    maintainer_email='your@email.com',  # 이메일
    description='Battlebot simulator package',  # 설명
    license='MIT',  # 라이선스
    tests_require=['pytest'],  # 테스트 요구 사항
    entry_points={
        'console_scripts': [
            'moving_obstacle_controller = battlebot_sim.moving_obstacle_controller:main',  # 이동 장애물 컨트롤러 실행
            'damage_calculator_node = battlebot_sim.damage_calculator_node:main',  # 데미지 계산 노드 실행
            'dual_teleop = battlebot_sim.dual_teleop:main',  # dual_teleop 실행
            'flipper_control = battlebot_sim.flipper_control:main',  # flipper 제어 노드 실행
        ],
    },
)

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from pynput import keyboard
import threading

class DualTeleop(Node):
    def __init__(self):
        super().__init__('dual_teleop_custom')
        # battlebot_1과 battlebot_2의 속도 명령을 위한 퍼블리셔 설정
        self.pub1 = self.create_publisher(Twist, '/battlebot_1/cmd_vel', 10)
        self.pub2 = self.create_publisher(Twist, '/battlebot_2/cmd_vel', 10)
        
        # 키 상태를 추적하기 위한 딕셔너리
        self.key_states = {
            'w': False, 's': False, 'a': False, 'd': False,  # battlebot_1 제어용
            'i': False, 'k': False, 'j': False, 'l': False,  # battlebot_2 제어용
            'q': False  # 종료 키
         }
        
        # 키보드 입력 리스너 설정
        self.listener = keyboard.Listener(on_press=self.on_press, on_release=self.on_release)
        self.listener.start()
        
        # 주기적 명령 발행 타이머
        self.timer = self.create_timer(0.1, self.publish_velocity)
        
        self.get_logger().info("DualTeleop 노드가 시작되었습니다. 'wasd'로 battlebot_1, 'ijkl'로 battlebot_2를 제어하세요. 'q'로 종료.")

    def on_press(self, key):
        """키가 눌렸을 때 호출"""
        try:
            char = key.char
            if char in self.key_states:
                self.key_states[char] = True
                self.get_logger().info(f"Key pressed: {char}")
        except AttributeError:
            pass
        except Exception as e:
            self.get_logger().error(f"Error in on_press: {str(e)}")

    def on_release(self, key):
        """키가 뗴어졌을 때 호출"""
        try:
            char = key.char
            if char in self.key_states:
                self.key_states[char] = False
                self.get_logger().info(f"Key released: {char}")
            if char == 'q':
                self.shutdown()
        except AttributeError:
            pass
        except Exception as e:
            self.get_logger().error(f"Error in on_release: {str(e)}")

    def publish_velocity(self):
        """현재 키 상태에 따라 속도 명령을 발행"""
        try:
            twist1 = Twist()
            twist2 = Twist()

            # battlebot_1 제어 (wasd)
            if self.key_states['w']:
                twist1.linear.x = 0.5
            elif self.key_states['s']:
                twist1.linear.x = -0.5
            if self.key_states['a']:
                twist1.angular.z = 1.0
            elif self.key_states['d']:
                twist1.angular.z = -1.0

            # battlebot_2 제어 (ijkl)
            if self.key_states['i']:
                twist2.linear.x = 0.5
            elif self.key_states['k']:
                twist2.linear.x = -0.5
            if self.key_states['j']:
                twist2.angular.z = 1.0
            elif self.key_states['l']:
                twist2.angular.z = -1.0

            if twist1.linear.x != 0.0 or twist1.angular.z != 0.0:
                self.pub1.publish(twist1)
                self.get_logger().info("Published velocity to battlebot_1: linear.x=%f, angular.z=%f", twist1.linear.x, twist1.angular.z)
            if twist2.linear.x != 0.0 or twist2.angular.z != 0.0:
                self.pub2.publish(twist2)
                self.get_logger().info("Published velocity to battlebot_2: linear.x=%f, angular.z=%f", twist2.linear.x, twist2.angular.z)
        except Exception as e:
            self.get_logger().error(f"Error in publish_velocity: {str(e)}")

    def shutdown(self):
        """노드를 깔끔하게 종료"""
        self.get_logger().info("DualTeleop 노드를 종료합니다.")
        self.timer.cancel()
        self.listener.stop()
        rclpy.shutdown()

def main():
    rclpy.init()
    node = DualTeleop()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("키보드 인터럽트로 종료합니다.")
    finally:
        if rclpy.ok():
            node.shutdown()

if __name__ == '__main__':
    main()

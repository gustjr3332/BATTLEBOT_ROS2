import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter

from gazebo_msgs.msg import ContactsState
from sensor_msgs.msg import Imu
from std_msgs.msg import Float32
from tf_transformations import euler_from_quaternion # 쿼터니언을 RPY로 변환하기 위한 라이브러리
import math

class DamageCalculator(Node):
    def __init__(self):
        super().__init__('damage_calculator')  # 노드 이름 설정

        # 파라미터 선언 및 초기값 설정
        self.declare_parameter('initial_health', 100.0)  # 초기 체력
        self.declare_parameter('contact_damage_per_event', 1.0)  # 기본 접촉 데미지
        self.declare_parameter('moving_obstacle_contact_damage', 5.0)  # 이동 장애물 접촉 데미지
        self.declare_parameter('saw_blade_contact_damage', 5.0)  # 톱날 접촉 데미지
        self.declare_parameter('flip_damage_per_event', 5.0)  # 뒤집힘 데미지
        self.declare_parameter('weapon_damage_saw', 10.0)  # 톱 무기 데미지
        self.declare_parameter('weapon_damage_hammer', 15.0)  # 망치 무기 데미지
        self.declare_parameter('flip_threshold_roll_deg', 90.0)  # 롤 각도 임계값 (도)
        self.declare_parameter('flip_threshold_pitch_deg', 90.0)  # 피치 각도 임계값 (도)

        # 파라미터 값 가져오기
        self.initial_health = self.get_parameter('initial_health').get_parameter_value().double_value
        self.damage_config = {
            'contact_damage': self.get_parameter('contact_damage_per_event').get_parameter_value().double_value,
            'moving_obstacle_contact_damage': self.get_parameter('moving_obstacle_contact_damage').get_parameter_value().double_value,
            'saw_blade_contact_damage': self.get_parameter('saw_blade_contact_damage').get_parameter_value().double_value,
            'flip_damage': self.get_parameter('flip_damage_per_event').get_parameter_value().double_value,
            'weapon_damage_saw': self.get_parameter('weapon_damage_saw').get_parameter_value().double_value,
            'weapon_damage_hammer': self.get_parameter('weapon_damage_hammer').get_parameter_value().double_value,
        }
        self.flip_threshold_roll_rad = math.radians(self.get_parameter('flip_threshold_roll_deg').get_parameter_value().double_value)
        self.flip_threshold_pitch_rad = math.radians(self.get_parameter('flip_threshold_pitch_deg').get_parameter_value().double_value)

        # 각 로봇의 체력 초기화
        self.robot_health = {
            "battlebot": self.initial_health,
            "moving_obstacle": self.initial_health,
        }

        # 접촉 센서 메시지를 구독
        self.contact_sub_battlebot = self.create_subscription(
            ContactsState,
            "/battlebot/contact",
            lambda msg: self.process_contact("battlebot", "moving_obstacle", msg),  # battlebot이 moving_obstacle을 공격
            10
        )
        self.contact_sub_obstacle = self.create_subscription(
            ContactsState,
            "/moving_obstacle/contact",
            lambda msg: self.process_contact("moving_obstacle", "battlebot", msg),  # moving_obstacle이 battlebot을 공격
            10
        )
        self.contact_sub_saw_blade_1 = self.create_subscription(
            ContactsState,
            "/saw_blade_1/contact",
            lambda msg: self.process_contact("saw_blade_1", "battlebot", msg),  # saw_blade_1이 battlebot을 공격
            10
        )
        self.contact_sub_saw_blade_2 = self.create_subscription(
            ContactsState,
            "/saw_blade_2/contact",
            lambda msg: self.process_contact("saw_blade_2", "battlebot", msg),  # saw_blade_2가 battlebot을 공격
            10
        )

        # IMU 센서 메시지를 구독
        self.imu_sub_battlebot = self.create_subscription(
            Imu,
            "/battlebot/imu",
            lambda msg: self.check_flip("battlebot", msg),
            10
        )
        self.imu_sub_obstacle = self.create_subscription(
            Imu,
            "/moving_obstacle/imu",
            lambda msg: self.check_flip("moving_obstacle", msg),
            10
        )

        # 체력 퍼블리셔 설정
        self.health_pub_battlebot = self.create_publisher(Float32, "/battlebot/health", 10)
        self.health_pub_obstacle = self.create_publisher(Float32, "/moving_obstacle/health", 10)

        # 주기적으로 체력을 발행하는 타이머
        self.timer = self.create_timer(0.5, self.publish_health)

        self.get_logger().info("DamageCalculator 노드가 시작되었습니다.")

        # 로봇이 뒤집혔는지 추적
        self.is_flipped = {
            "battlebot": False,
        }

    def process_contact(self, attacker_bot_name, target_bot_name, msg):
        """접촉 이벤트를 처리하여 데미지를 계산"""
        if msg.states:
            for contact_state in msg.states:
                target_hit = (target_bot_name in contact_state.collision1_name or
                              target_bot_name in contact_state.collision2_name)
                if target_hit:
                    self.get_logger().info(f"{attacker_bot_name}이(가) {target_bot_name}와 접촉했습니다!")
                    damage_amount = 0.0
                    
                    # 이동 장애물이 battlebot을 공격
                    if attacker_bot_name == "moving_obstacle" and target_bot_name == "battlebot":
                        damage_amount = self.damage_config['moving_obstacle_contact_damage']
                        self.get_logger().info(f"이동 장애물이 battlebot을 공격! 데미지: {damage_amount}")
                    
                    # 톱날이 battlebot을 공격
                    elif (attacker_bot_name == "saw_blade_1" or attacker_bot_name == "saw_blade_2") \
                         and target_bot_name == "battlebot":
                        damage_amount = self.damage_config['saw_blade_contact_damage']
                        self.get_logger().info(f"{attacker_bot_name}이(가) battlebot을 공격! 데미지: {damage_amount}")
                    
                    # battlebot이 무기로 공격
                    elif attacker_bot_name == "battlebot":
                        saw_hit_by_battlebot = ("saw" in contact_state.collision1_name or
                                                "saw" in contact_state.collision2_name)
                        hammer_hit_by_battlebot = ("hammer" in contact_state.collision1_name or
                                                   "hammer" in contact_state.collision2_name)
                        if saw_hit_by_battlebot:
                            damage_amount = self.damage_config['weapon_damage_saw']
                            self.get_logger().info(f"{attacker_bot_name}의 톱이 {target_bot_name}을 공격! 데미지: {damage_amount}")
                        elif hammer_hit_by_battlebot:
                            damage_amount = self.damage_config['weapon_damage_hammer']
                            self.get_logger().info(f"{attacker_bot_name}의 망치가 {target_bot_name}을 공격! 데미지: {damage_amount}")
                        else:
                            damage_amount = self.damage_config['contact_damage']
                            self.get_logger().info(f"{attacker_bot_name}의 몸체가 {target_bot_name}을 공격! 데미지: {damage_amount}")
                    
                    if damage_amount == 0.0:
                        self.get_logger().debug(f"{attacker_bot_name}이(가) {target_bot_name}을 공격했으나 데미지 규칙 없음.")
                        continue

                    self.robot_health[target_bot_name] -= damage_amount
                    if self.robot_health[target_bot_name] < 0:
                        self.robot_health[target_bot_name] = 0
                        self.get_logger().warn(f"{target_bot_name}의 체력이 0이 되었습니다!")
                    self.publish_health()
                    break

    def check_flip(self, bot_name, msg):
        """IMU 데이터를 확인하여 로봇이 뒤집혔는지 체크"""
        orientation_q = msg.orientation
        orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
        (roll, pitch, yaw) = euler_from_quaternion(orientation_list)

        if abs(roll) > self.flip_threshold_roll_rad or abs(pitch) > self.flip_threshold_pitch_rad:
            if not self.is_flipped[bot_name]:
                self.robot_health[bot_name] -= self.damage_config['flip_damage']
                self.get_logger().warn(f"{bot_name}이(가) 뒤집혔습니다! 체력: {self.robot_health[bot_name]:.2f}")
                self.is_flipped[bot_name] = True
                self.publish_health()
        else:
            self.is_flipped[bot_name] = False

    def publish_health(self):
        """현재 체력을 발행"""
        health_msg = Float32()
        health_msg.data = self.robot_health["battlebot"]
        self.health_pub_battlebot.publish(health_msg)
        if "moving_obstacle" in self.robot_health:
            health_msg.data = self.robot_health["moving_obstacle"]
            self.health_pub_obstacle.publish(health_msg)

def main(args=None):
    rclpy.init(args=args)
    damage_calculator = DamageCalculator()
    rclpy.spin(damage_calculator)
    damage_calculator.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

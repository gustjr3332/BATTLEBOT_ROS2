import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from pynput import keyboard
import threading

class FlipperControl(Node):
    def __init__(self):
        super().__init__('flipper_control')
        # 키 상태 딕셔너리
        self.key_states = {
            'q': False   # 종료 키
        }

        # 비차단 키보드 입력 리스너
        self.listener = keyboard.Listener(on_press=self.on_press, on_release=self.on_release)
        self.listener.start()

        self.get_logger().info("FlipperControl 노드가 시작되었습니다. 'q'로 종료하세요.")

    def on_press(self, key):
        """키가 눌렸을 때 호출"""
        try:
            char = key.char
            if char in self.key_states:
                self.key_states[char] = True
        except AttributeError:
            pass

    def on_release(self, key):
        """키가 뗴어졌을 때 호출"""
        try:
            char = key.char
            if char in self.key_states:
                self.key_states[char] = False
            if char == 'q':
                self.shutdown()
        except AttributeError:
            pass

    def shutdown(self):
        """노드 종료"""
        self.get_logger().info("FlipperControl 노드를 종료합니다.")
        self.listener.stop()
        rclpy.shutdown()

def main():
    rclpy.init()
    node = FlipperControl()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("키보드 인터럽트로 종료합니다.")
    finally:
        if rclpy.ok():
            node.shutdown()

if __name__ == '__main__':
    main()

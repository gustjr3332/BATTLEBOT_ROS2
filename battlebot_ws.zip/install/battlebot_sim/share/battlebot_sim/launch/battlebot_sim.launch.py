from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    pkg_share = get_package_share_directory('battlebot_sim')
    world_file = os.path.join(pkg_share, 'worlds', 'arena.world')
    urdf_file = os.path.join(pkg_share, 'urdf', 'battlebot_scaled.urdf')

    return LaunchDescription([
        ExecuteProcess(
            cmd=['ign', 'gazebo', '-v', '4', '-r', world_file],
            output='screen'
        ),
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': open(urdf_file).read()}]
        ),
        Node(
            package='ros_ign_gazebo',
            executable='create',
            arguments=[
                '-topic', '/robot_description',
                '-name', 'battlebot_scaled',
                '-x', '0', '-y', '0', '-z', '0.4'
            ],
            output='screen'
        ),
    ])
